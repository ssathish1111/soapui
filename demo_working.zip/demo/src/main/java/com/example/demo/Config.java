package com.example.demo;

import java.io.IOException;
import java.net.http.HttpClient;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import com.example.demo.SOAPConnector;

import jakarta.xml.soap.MessageFactory;
import jakarta.xml.soap.SOAPConstants;
import jakarta.xml.soap.SOAPException;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

@Configuration
public class Config {
    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this is the package name specified in the <generatePackage> specified in
        // pom.xml
        marshaller.setContextPath("com.example.demo.wsdl");
        return marshaller;
    }

    @Bean
    public SOAPConnector soapConnector(Jaxb2Marshaller marshaller) {
        SOAPConnector client = new SOAPConnector();
        client.setDefaultUri("https://uat.serversidegraphics.com/pcs/services/");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }

    @Bean
    public HttpComponentsMessageSender httpComponentsMessageSender() {
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();

        messageSender
                .setHttpClient(HttpClients.custom().setProxy(new HttpHost("uat.serversidegraphics.com", 443)).build());

        // Set timeouts
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(10000) // 10 seconds
                .setSocketTimeout(10000) // 10 seconds
                .build();

        messageSender.setHttpClient(HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .build());

        return messageSender;
    }

    @Bean
    public WebServiceTemplate webServiceTemplate(Jaxb2Marshaller marshaller,
            HttpComponentsMessageSender messageSender) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        webServiceTemplate.setMarshaller(marshaller);
        webServiceTemplate.setUnmarshaller(marshaller);
        webServiceTemplate.setMessageSender(messageSender);

        try {
            MessageFactory messageFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
            SaajSoapMessageFactory saajSoapMessageFactory = new SaajSoapMessageFactory(messageFactory);
            webServiceTemplate.setMessageFactory(saajSoapMessageFactory);
        } catch (SOAPException e) {
            throw new RuntimeException("Error creating SAAJ MessageFactory", e);
        }

        ClientInterceptor[] interceptors = new ClientInterceptor[] { new SoapLogTraceInterceptor(),
                new SoapActionInterceptor() };
        webServiceTemplate.setInterceptors(interceptors);

        return webServiceTemplate;
    }
}
