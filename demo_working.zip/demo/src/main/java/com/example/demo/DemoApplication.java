package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.wsdl.ImageInformation;
import com.example.demo.wsdl.ImageInformationResponse;

@SpringBootApplication
public class DemoApplication {

  @Autowired

  public static void main(String[] args) {
    SpringApplication.run(DemoApplication.class, args);
  }

  @Bean
  CommandLineRunner lookup(SOAPConnector soapConnector) {
    return args -> {

      String name = "Lokesh"; // Default Name

      if (args.length > 0) {
        name = args[0];
      }

      ImageInformation request = new ImageInformation();
      request.setCardImageId("test");
      request.setImageInformationKey("24");
      ImageInformationResponse imageInformationResponse = (ImageInformationResponse) soapConnector
          .callWebService("https://uat.serversidegraphics.com/pcs/services/information4.asmx", request);
      System.out.println("Got Response As below ========= : ");
      System.out.println("Name : " + imageInformationResponse.getImageInformationResult().getCardImageID());
      System.out.println("Name : " + imageInformationResponse.getImageInformationResult().getDesignState());

      /*
       * StudentDetailsRequest request = new StudentDetailsRequest();
       * request.setName(name);
       * StudentDetailsResponse response = (StudentDetailsResponse)
       * soapConnector.callWebService("http://localhost:8080/service/student-details",
       * request);
       * System.out.println("Got Response As below ========= : ");
       * System.out.println("Name : " + response.getStudent().getName());
       * System.out.println("Standard : " + response.getStudent().getStandard());
       * System.out.println("Address : " + response.getStudent().getAddress());
       */
    };

  }
}
