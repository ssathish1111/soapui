
package com.example.demo.wsdl;

import jakarta.xml.bind.annotation.XmlRegistry;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.example.consumingwebservice.wsdl package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema
     * derived classes for package: com.example.consumingwebservice.wsdl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ImageInformation }
     * 
     */
    public ImageInformation createImageInformation() {
        return new ImageInformation();
    }

    /**
     * Create an instance of {@link ImageInformationResponse }
     * 
     */
    public ImageInformationResponse createImageInformationResponse() {
        return new ImageInformationResponse();
    }

    /**
     * Create an instance of {@link ImageInformation4Result }
     * 
     */
    public ImageInformation4Result createImageInformation4Result() {
        return new ImageInformation4Result();
    }

    /**
     * Create an instance of {@link SetTransactionApprovalState }
     * 
     */
    public SetTransactionApprovalState createSetTransactionApprovalState() {
        return new SetTransactionApprovalState();
    }

    /**
     * Create an instance of {@link SetTransactionApprovalStateResponse }
     * 
     */
    public SetTransactionApprovalStateResponse createSetTransactionApprovalStateResponse() {
        return new SetTransactionApprovalStateResponse();
    }

    /**
     * Create an instance of {@link SetEmailAddress }
     * 
     */
    public SetEmailAddress createSetEmailAddress() {
        return new SetEmailAddress();
    }

    /**
     * Create an instance of {@link SetEmailAddressResponse }
     * 
     */
    public SetEmailAddressResponse createSetEmailAddressResponse() {
        return new SetEmailAddressResponse();
    }

    /**
     * Create an instance of {@link SetCustomDataCapture }
     * 
     */
    public SetCustomDataCapture createSetCustomDataCapture() {
        return new SetCustomDataCapture();
    }

    /**
     * Create an instance of {@link SetCustomDataCaptureResponse }
     * 
     */
    public SetCustomDataCaptureResponse createSetCustomDataCaptureResponse() {
        return new SetCustomDataCaptureResponse();
    }

    /**
     * Create an instance of {@link SetProductSwap }
     * 
     */
    public SetProductSwap createSetProductSwap() {
        return new SetProductSwap();
    }

    /**
     * Create an instance of {@link SetProductSwapRequest }
     * 
     */
    public SetProductSwapRequest createSetProductSwapRequest() {
        return new SetProductSwapRequest();
    }

    /**
     * Create an instance of {@link SetProductSwapResponse }
     * 
     */
    public SetProductSwapResponse createSetProductSwapResponse() {
        return new SetProductSwapResponse();
    }

    /**
     * Create an instance of {@link SetProductSwapResult }
     * 
     */
    public SetProductSwapResult createSetProductSwapResult() {
        return new SetProductSwapResult();
    }

    /**
     * Create an instance of {@link ArrayOfDataCaptureRecordWrapper }
     * 
     */
    public ArrayOfDataCaptureRecordWrapper createArrayOfDataCaptureRecordWrapper() {
        return new ArrayOfDataCaptureRecordWrapper();
    }

    /**
     * Create an instance of {@link DataCaptureRecordWrapper }
     * 
     */
    public DataCaptureRecordWrapper createDataCaptureRecordWrapper() {
        return new DataCaptureRecordWrapper();
    }

}
