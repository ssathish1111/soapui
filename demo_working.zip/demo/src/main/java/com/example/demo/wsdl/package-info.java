@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://pcs.webservices.serversidegraphics.com/1", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.example.demo.wsdl;
