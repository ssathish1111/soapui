package com.example.demo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.LoggerFactory;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import ch.qos.logback.classic.Logger;

public class SoapLogTraceInterceptor implements ClientInterceptor {
    private static final Logger logger = (Logger) LoggerFactory.getLogger(SoapLogTraceInterceptor.class);

    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        SaajSoapMessage soapMessage = (SaajSoapMessage) messageContext.getRequest();
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            soapMessage.writeTo(out);
            logger.info("SOAP Request: " + new String(out.toByteArray()));
        } catch (IOException e) {
            logger.error("Error logging SOAP request", e);
        }
        return true;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        SaajSoapMessage soapMessage = (SaajSoapMessage) messageContext.getResponse();
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            soapMessage.writeTo(out);
            logger.info("SOAP Response: " + new String(out.toByteArray()));
        } catch (IOException e) {
            logger.error("Error logging SOAP response", e);
        }
        return true;
    }

    @Override
    public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
        SaajSoapMessage soapMessage = (SaajSoapMessage) messageContext.getResponse();
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            soapMessage.writeTo(out);
            logger.info("SOAP Fault: " + new String(out.toByteArray()));
        } catch (IOException e) {
            logger.error("Error logging SOAP fault", e);
        }
        return true;
    }

    @Override
    public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {
        // No-op
    }
}
