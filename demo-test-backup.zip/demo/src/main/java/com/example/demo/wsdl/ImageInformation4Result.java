
package com.example.demo.wsdl;

import javax.xml.datatype.XMLGregorianCalendar;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ImageInformation4Result complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="ImageInformation4Result"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CardImageID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DesignState" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="Handover_Key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RejectionReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ImageType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TransactionApprovalState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="StockImageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CardPrinted" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="CardMailed" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="ImageCheckingStartTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="ImageCheckingEndTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="TransactionApprovalStateName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TransactionApprovalStateID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="AggregatorName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AggregatorID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="SubscriberName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubscriberID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="DesignCreatedTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="DesignStateTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="DesignStateName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DesignStateID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="DesignTransferStateName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DesignTransferStateID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="DesignTransferTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EmailSent" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="LanguageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PublicImage" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="ClientRefererId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TransactionApprovalTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="TransactionApprovalComment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TransferredDefaultImage" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="BatchFileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatchFileTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="Processed" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="DataFields" type="{http://pcs.webservices.serversidegraphics.com/1}ArrayOfDataCaptureRecordWrapper" minOccurs="0"/&gt;
 *         &lt;element name="CustomImagePricePoint" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TextLayerPricePoint" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ImageInformation4Result", propOrder = {
        "cardImageID",
        "designState",
        "errorCode",
        "handoverKey",
        "rejectionReason",
        "imageType",
        "transactionApprovalState",
        "stockImageCode",
        "cardPrinted",
        "cardMailed",
        "imageCheckingStartTimeStamp",
        "imageCheckingEndTimeStamp",
        "transactionApprovalStateName",
        "transactionApprovalStateID",
        "aggregatorName",
        "aggregatorID",
        "subscriberName",
        "subscriberID",
        "productName",
        "productID",
        "designCreatedTimeStamp",
        "designStateTimeStamp",
        "designStateName",
        "designStateID",
        "designTransferStateName",
        "designTransferStateID",
        "designTransferTimeStamp",
        "emailAddress",
        "emailSent",
        "languageId",
        "publicImage",
        "clientRefererId",
        "transactionApprovalTimeStamp",
        "transactionApprovalComment",
        "transferredDefaultImage",
        "batchFileName",
        "batchFileTimeStamp",
        "processed",
        "dataFields",
        "customImagePricePoint",
        "textLayerPricePoint"
})
public class ImageInformation4Result {

    @XmlElement(name = "CardImageID")
    protected String cardImageID;
    @XmlElement(name = "DesignState")
    protected int designState;
    @XmlElement(name = "ErrorCode")
    protected int errorCode;
    @XmlElement(name = "Handover_Key")
    protected String handoverKey;
    @XmlElement(name = "RejectionReason")
    protected String rejectionReason;
    @XmlElement(name = "ImageType")
    protected String imageType;
    @XmlElement(name = "TransactionApprovalState")
    protected String transactionApprovalState;
    @XmlElement(name = "StockImageCode")
    protected String stockImageCode;
    @XmlElement(name = "CardPrinted", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar cardPrinted;
    @XmlElement(name = "CardMailed", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar cardMailed;
    @XmlElement(name = "ImageCheckingStartTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar imageCheckingStartTimeStamp;
    @XmlElement(name = "ImageCheckingEndTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar imageCheckingEndTimeStamp;
    @XmlElement(name = "TransactionApprovalStateName")
    protected String transactionApprovalStateName;
    @XmlElement(name = "TransactionApprovalStateID")
    protected int transactionApprovalStateID;
    @XmlElement(name = "AggregatorName")
    protected String aggregatorName;
    @XmlElement(name = "AggregatorID")
    protected int aggregatorID;
    @XmlElement(name = "SubscriberName")
    protected String subscriberName;
    @XmlElement(name = "SubscriberID")
    protected int subscriberID;
    @XmlElement(name = "ProductName")
    protected String productName;
    @XmlElement(name = "ProductID")
    protected int productID;
    @XmlElement(name = "DesignCreatedTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar designCreatedTimeStamp;
    @XmlElement(name = "DesignStateTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar designStateTimeStamp;
    @XmlElement(name = "DesignStateName")
    protected String designStateName;
    @XmlElement(name = "DesignStateID")
    protected int designStateID;
    @XmlElement(name = "DesignTransferStateName")
    protected String designTransferStateName;
    @XmlElement(name = "DesignTransferStateID")
    protected int designTransferStateID;
    @XmlElement(name = "DesignTransferTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar designTransferTimeStamp;
    @XmlElement(name = "EmailAddress")
    protected String emailAddress;
    @XmlElement(name = "EmailSent")
    protected boolean emailSent;
    @XmlElement(name = "LanguageId")
    protected String languageId;
    @XmlElement(name = "PublicImage")
    protected boolean publicImage;
    @XmlElement(name = "ClientRefererId")
    protected String clientRefererId;
    @XmlElement(name = "TransactionApprovalTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar transactionApprovalTimeStamp;
    @XmlElement(name = "TransactionApprovalComment")
    protected String transactionApprovalComment;
    @XmlElement(name = "TransferredDefaultImage")
    protected boolean transferredDefaultImage;
    @XmlElement(name = "BatchFileName")
    protected String batchFileName;
    @XmlElement(name = "BatchFileTimeStamp", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar batchFileTimeStamp;
    @XmlElement(name = "Processed", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar processed;
    @XmlElement(name = "DataFields")
    protected ArrayOfDataCaptureRecordWrapper dataFields;
    @XmlElement(name = "CustomImagePricePoint")
    protected String customImagePricePoint;
    @XmlElement(name = "TextLayerPricePoint")
    protected String textLayerPricePoint;

    /**
     * Gets the value of the cardImageID property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getCardImageID() {
        return cardImageID;
    }

    /**
     * Sets the value of the cardImageID property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setCardImageID(String value) {
        this.cardImageID = value;
    }

    /**
     * Gets the value of the designState property.
     * 
     */
    public int getDesignState() {
        return designState;
    }

    /**
     * Sets the value of the designState property.
     * 
     */
    public void setDesignState(int value) {
        this.designState = value;
    }

    /**
     * Gets the value of the errorCode property.
     * 
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     * 
     */
    public void setErrorCode(int value) {
        this.errorCode = value;
    }

    /**
     * Gets the value of the handoverKey property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getHandoverKey() {
        return handoverKey;
    }

    /**
     * Sets the value of the handoverKey property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setHandoverKey(String value) {
        this.handoverKey = value;
    }

    /**
     * Gets the value of the rejectionReason property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getRejectionReason() {
        return rejectionReason;
    }

    /**
     * Sets the value of the rejectionReason property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setRejectionReason(String value) {
        this.rejectionReason = value;
    }

    /**
     * Gets the value of the imageType property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getImageType() {
        return imageType;
    }

    /**
     * Sets the value of the imageType property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setImageType(String value) {
        this.imageType = value;
    }

    /**
     * Gets the value of the transactionApprovalState property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getTransactionApprovalState() {
        return transactionApprovalState;
    }

    /**
     * Sets the value of the transactionApprovalState property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setTransactionApprovalState(String value) {
        this.transactionApprovalState = value;
    }

    /**
     * Gets the value of the stockImageCode property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getStockImageCode() {
        return stockImageCode;
    }

    /**
     * Sets the value of the stockImageCode property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setStockImageCode(String value) {
        this.stockImageCode = value;
    }

    /**
     * Gets the value of the cardPrinted property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getCardPrinted() {
        return cardPrinted;
    }

    /**
     * Sets the value of the cardPrinted property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setCardPrinted(XMLGregorianCalendar value) {
        this.cardPrinted = value;
    }

    /**
     * Gets the value of the cardMailed property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getCardMailed() {
        return cardMailed;
    }

    /**
     * Sets the value of the cardMailed property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setCardMailed(XMLGregorianCalendar value) {
        this.cardMailed = value;
    }

    /**
     * Gets the value of the imageCheckingStartTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getImageCheckingStartTimeStamp() {
        return imageCheckingStartTimeStamp;
    }

    /**
     * Sets the value of the imageCheckingStartTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setImageCheckingStartTimeStamp(XMLGregorianCalendar value) {
        this.imageCheckingStartTimeStamp = value;
    }

    /**
     * Gets the value of the imageCheckingEndTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getImageCheckingEndTimeStamp() {
        return imageCheckingEndTimeStamp;
    }

    /**
     * Sets the value of the imageCheckingEndTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setImageCheckingEndTimeStamp(XMLGregorianCalendar value) {
        this.imageCheckingEndTimeStamp = value;
    }

    /**
     * Gets the value of the transactionApprovalStateName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getTransactionApprovalStateName() {
        return transactionApprovalStateName;
    }

    /**
     * Sets the value of the transactionApprovalStateName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setTransactionApprovalStateName(String value) {
        this.transactionApprovalStateName = value;
    }

    /**
     * Gets the value of the transactionApprovalStateID property.
     * 
     */
    public int getTransactionApprovalStateID() {
        return transactionApprovalStateID;
    }

    /**
     * Sets the value of the transactionApprovalStateID property.
     * 
     */
    public void setTransactionApprovalStateID(int value) {
        this.transactionApprovalStateID = value;
    }

    /**
     * Gets the value of the aggregatorName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getAggregatorName() {
        return aggregatorName;
    }

    /**
     * Sets the value of the aggregatorName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setAggregatorName(String value) {
        this.aggregatorName = value;
    }

    /**
     * Gets the value of the aggregatorID property.
     * 
     */
    public int getAggregatorID() {
        return aggregatorID;
    }

    /**
     * Sets the value of the aggregatorID property.
     * 
     */
    public void setAggregatorID(int value) {
        this.aggregatorID = value;
    }

    /**
     * Gets the value of the subscriberName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getSubscriberName() {
        return subscriberName;
    }

    /**
     * Sets the value of the subscriberName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setSubscriberName(String value) {
        this.subscriberName = value;
    }

    /**
     * Gets the value of the subscriberID property.
     * 
     */
    public int getSubscriberID() {
        return subscriberID;
    }

    /**
     * Sets the value of the subscriberID property.
     * 
     */
    public void setSubscriberID(int value) {
        this.subscriberID = value;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the productID property.
     * 
     */
    public int getProductID() {
        return productID;
    }

    /**
     * Sets the value of the productID property.
     * 
     */
    public void setProductID(int value) {
        this.productID = value;
    }

    /**
     * Gets the value of the designCreatedTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getDesignCreatedTimeStamp() {
        return designCreatedTimeStamp;
    }

    /**
     * Sets the value of the designCreatedTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setDesignCreatedTimeStamp(XMLGregorianCalendar value) {
        this.designCreatedTimeStamp = value;
    }

    /**
     * Gets the value of the designStateTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getDesignStateTimeStamp() {
        return designStateTimeStamp;
    }

    /**
     * Sets the value of the designStateTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setDesignStateTimeStamp(XMLGregorianCalendar value) {
        this.designStateTimeStamp = value;
    }

    /**
     * Gets the value of the designStateName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getDesignStateName() {
        return designStateName;
    }

    /**
     * Sets the value of the designStateName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setDesignStateName(String value) {
        this.designStateName = value;
    }

    /**
     * Gets the value of the designStateID property.
     * 
     */
    public int getDesignStateID() {
        return designStateID;
    }

    /**
     * Sets the value of the designStateID property.
     * 
     */
    public void setDesignStateID(int value) {
        this.designStateID = value;
    }

    /**
     * Gets the value of the designTransferStateName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getDesignTransferStateName() {
        return designTransferStateName;
    }

    /**
     * Sets the value of the designTransferStateName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setDesignTransferStateName(String value) {
        this.designTransferStateName = value;
    }

    /**
     * Gets the value of the designTransferStateID property.
     * 
     */
    public int getDesignTransferStateID() {
        return designTransferStateID;
    }

    /**
     * Sets the value of the designTransferStateID property.
     * 
     */
    public void setDesignTransferStateID(int value) {
        this.designTransferStateID = value;
    }

    /**
     * Gets the value of the designTransferTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getDesignTransferTimeStamp() {
        return designTransferTimeStamp;
    }

    /**
     * Sets the value of the designTransferTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setDesignTransferTimeStamp(XMLGregorianCalendar value) {
        this.designTransferTimeStamp = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the emailSent property.
     * 
     */
    public boolean isEmailSent() {
        return emailSent;
    }

    /**
     * Sets the value of the emailSent property.
     * 
     */
    public void setEmailSent(boolean value) {
        this.emailSent = value;
    }

    /**
     * Gets the value of the languageId property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getLanguageId() {
        return languageId;
    }

    /**
     * Sets the value of the languageId property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setLanguageId(String value) {
        this.languageId = value;
    }

    /**
     * Gets the value of the publicImage property.
     * 
     */
    public boolean isPublicImage() {
        return publicImage;
    }

    /**
     * Sets the value of the publicImage property.
     * 
     */
    public void setPublicImage(boolean value) {
        this.publicImage = value;
    }

    /**
     * Gets the value of the clientRefererId property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getClientRefererId() {
        return clientRefererId;
    }

    /**
     * Sets the value of the clientRefererId property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setClientRefererId(String value) {
        this.clientRefererId = value;
    }

    /**
     * Gets the value of the transactionApprovalTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getTransactionApprovalTimeStamp() {
        return transactionApprovalTimeStamp;
    }

    /**
     * Sets the value of the transactionApprovalTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setTransactionApprovalTimeStamp(XMLGregorianCalendar value) {
        this.transactionApprovalTimeStamp = value;
    }

    /**
     * Gets the value of the transactionApprovalComment property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getTransactionApprovalComment() {
        return transactionApprovalComment;
    }

    /**
     * Sets the value of the transactionApprovalComment property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setTransactionApprovalComment(String value) {
        this.transactionApprovalComment = value;
    }

    /**
     * Gets the value of the transferredDefaultImage property.
     * 
     */
    public boolean isTransferredDefaultImage() {
        return transferredDefaultImage;
    }

    /**
     * Sets the value of the transferredDefaultImage property.
     * 
     */
    public void setTransferredDefaultImage(boolean value) {
        this.transferredDefaultImage = value;
    }

    /**
     * Gets the value of the batchFileName property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getBatchFileName() {
        return batchFileName;
    }

    /**
     * Sets the value of the batchFileName property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setBatchFileName(String value) {
        this.batchFileName = value;
    }

    /**
     * Gets the value of the batchFileTimeStamp property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getBatchFileTimeStamp() {
        return batchFileTimeStamp;
    }

    /**
     * Sets the value of the batchFileTimeStamp property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setBatchFileTimeStamp(XMLGregorianCalendar value) {
        this.batchFileTimeStamp = value;
    }

    /**
     * Gets the value of the processed property.
     * 
     * @return
     *         possible object is
     *         {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getProcessed() {
        return processed;
    }

    /**
     * Sets the value of the processed property.
     * 
     * @param value
     *              allowed object is
     *              {@link XMLGregorianCalendar }
     * 
     */
    public void setProcessed(XMLGregorianCalendar value) {
        this.processed = value;
    }

    /**
     * Gets the value of the dataFields property.
     * 
     * @return
     *         possible object is
     *         {@link ArrayOfDataCaptureRecordWrapper }
     * 
     */
    public ArrayOfDataCaptureRecordWrapper getDataFields() {
        return dataFields;
    }

    /**
     * Sets the value of the dataFields property.
     * 
     * @param value
     *              allowed object is
     *              {@link ArrayOfDataCaptureRecordWrapper }
     * 
     */
    public void setDataFields(ArrayOfDataCaptureRecordWrapper value) {
        this.dataFields = value;
    }

    /**
     * Gets the value of the customImagePricePoint property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getCustomImagePricePoint() {
        return customImagePricePoint;
    }

    /**
     * Sets the value of the customImagePricePoint property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setCustomImagePricePoint(String value) {
        this.customImagePricePoint = value;
    }

    /**
     * Gets the value of the textLayerPricePoint property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getTextLayerPricePoint() {
        return textLayerPricePoint;
    }

    /**
     * Sets the value of the textLayerPricePoint property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setTextLayerPricePoint(String value) {
        this.textLayerPricePoint = value;
    }

}
