package com.example.demo;

import java.io.IOException;
import java.net.http.HttpClient;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

@Configuration
public class config {

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setPackagesToScan("com.example.demo.wsdl");
        marshaller.setCheckForXmlRootElement(false);
        return marshaller;
    }

    @Bean
    public SoapClientService getWebServiceTemplate(Jaxb2Marshaller marshaller) {
        SoapClientService soapClientService = new SoapClientService();

        WebServiceTemplate template = new WebServiceTemplate();
        template.setInterceptors(new SoapLogTraceInterceptor[] { new SoapLogTraceInterceptor() });
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(5000) // 5 seconds
                .setSocketTimeout(5000) // 5 seconds
                .build();

        messageSender.setHttpClient(HttpClients.custom().setProxy(new HttpHost("uat.serversidegraphics.com", 443))
                .setDefaultRequestConfig(requestConfig)
                .addInterceptorFirst(new HttpRequestInterceptor() {
                    @Override
                    public void process(HttpRequest request, HttpContext context) throws HttpException, IOException {
                        request.setHeader("Content-Type", "text/xml; charset=utf-8");
                    }
                })
                .build());
        template.setMessageSender(messageSender);
        soapClientService.setDefaultUri("https://uat.serversidegraphics.com/");
        soapClientService.setMarshaller(marshaller);
        soapClientService.setUnmarshaller(marshaller);
        soapClientService.setWebServiceTemplate(template);

        return soapClientService;
    }

}