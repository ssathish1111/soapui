package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.example.demo.wsdl.ImageInformation;
import com.example.demo.wsdl.ImageInformation4Result;
import com.example.demo.wsdl.ImageInformationResponse;

@Service
public class SoapClientService extends WebServiceGatewaySupport {

    public ImageInformationResponse callSoapService(ImageInformation request) {

        SoapActionCallback soapActionCallback = new SoapActionCallback(
                "http://microsoft.com");
        return (ImageInformationResponse) getWebServiceTemplate()
                .marshalSendAndReceive("https://uat.serversidegraphics.com:443/pcs/services/information4.asmx", request,
                        soapActionCallback);
    }
}