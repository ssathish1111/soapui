
package com.example.demo.wsdl;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for SetProductSwapRequest complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="SetProductSwapRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CardImageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ImageInformation_Key" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="ProductHandover_Key" type="{http://microsoft.com/wsdl/types/}guid"/&gt;
 *         &lt;element name="TransactionApprovalState" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="Comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SetProductSwapRequest", propOrder = {
        "cardImageId",
        "imageInformationKey",
        "productHandoverKey",
        "transactionApprovalState",
        "comment"
})
public class SetProductSwapRequest {

    @XmlElement(name = "CardImageId")
    protected String cardImageId;
    @XmlElement(name = "ImageInformation_Key", required = true)
    protected String imageInformationKey;
    @XmlElement(name = "ProductHandover_Key", required = true)
    protected String productHandoverKey;
    @XmlElement(name = "TransactionApprovalState", required = true, type = Integer.class, nillable = true)
    protected Integer transactionApprovalState;
    @XmlElement(name = "Comment")
    protected String comment;

    /**
     * Gets the value of the cardImageId property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getCardImageId() {
        return cardImageId;
    }

    /**
     * Sets the value of the cardImageId property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setCardImageId(String value) {
        this.cardImageId = value;
    }

    /**
     * Gets the value of the imageInformationKey property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getImageInformationKey() {
        return imageInformationKey;
    }

    /**
     * Sets the value of the imageInformationKey property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setImageInformationKey(String value) {
        this.imageInformationKey = value;
    }

    /**
     * Gets the value of the productHandoverKey property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getProductHandoverKey() {
        return productHandoverKey;
    }

    /**
     * Sets the value of the productHandoverKey property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setProductHandoverKey(String value) {
        this.productHandoverKey = value;
    }

    /**
     * Gets the value of the transactionApprovalState property.
     * 
     * @return
     *         possible object is
     *         {@link Integer }
     * 
     */
    public Integer getTransactionApprovalState() {
        return transactionApprovalState;
    }

    /**
     * Sets the value of the transactionApprovalState property.
     * 
     * @param value
     *              allowed object is
     *              {@link Integer }
     * 
     */
    public void setTransactionApprovalState(Integer value) {
        this.transactionApprovalState = value;
    }

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *         possible object is
     *         {@link String }
     * 
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *              allowed object is
     *              {@link String }
     * 
     */
    public void setComment(String value) {
        this.comment = value;
    }

}
